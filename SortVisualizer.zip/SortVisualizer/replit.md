# Sorting Algorithm Visualizer

## Overview

This is a full-stack web application built to visualize various sorting algorithms. The project demonstrates an interactive educational tool that allows users to watch sorting algorithms in action with visual representations, adjustable parameters, and real-time statistics.

## System Architecture

The application follows a modern full-stack architecture with clear separation between client and server components:

- **Frontend**: React-based single-page application with TypeScript
- **Backend**: Express.js server with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Build System**: Vite for frontend bundling, esbuild for backend compilation
- **Styling**: Tailwind CSS with shadcn/ui component library
- **Deployment**: Replit with autoscale deployment target

## Key Components

### Frontend Architecture
- **React 18** with TypeScript for type safety
- **Wouter** for client-side routing (lightweight alternative to React Router)
- **TanStack Query** for server state management and caching
- **shadcn/ui** component library built on Radix UI primitives
- **Tailwind CSS** for utility-first styling
- **Custom sorting visualization** with animated bar charts

### Backend Architecture
- **Express.js** server with TypeScript
- **Modular route structure** with separate route handlers
- **Memory-based storage** with interface for easy database migration
- **Development middleware** for logging and error handling
- **Vite integration** for hot module replacement in development

### Database Schema
- **Users table** with id, username, and password fields
- **Drizzle ORM** for type-safe database operations
- **PostgreSQL** as the target database (configured but not yet implemented)
- **Zod validation** for input validation

### UI Components
- **Comprehensive component library** with 40+ reusable UI components
- **Consistent theming** with CSS custom properties
- **Responsive design** with mobile-first approach
- **Accessibility features** built into all components

## Data Flow

1. **Client-side rendering**: React components manage local state for visualization
2. **API communication**: TanStack Query handles server requests with caching
3. **Real-time updates**: Sorting algorithms update UI state through React hooks
4. **Animation system**: Custom timing controls for visualization speed
5. **State management**: Local React state for visualization, TanStack Query for server state

## External Dependencies

### Core Framework Dependencies
- **React ecosystem**: react, react-dom, @tanstack/react-query
- **Backend**: express, drizzle-orm, @neondatabase/serverless
- **Build tools**: vite, esbuild, tsx
- **UI components**: @radix-ui/* packages, tailwindcss

### Development Dependencies
- **TypeScript** for type checking
- **Tailwind CSS** for styling
- **PostCSS** for CSS processing
- **Replit-specific**: @replit/vite-plugin-runtime-error-modal

## Deployment Strategy

The application is configured for deployment on Replit with the following setup:

- **Development**: `npm run dev` starts both frontend and backend with hot reloading
- **Build**: `npm run build` compiles frontend with Vite and backend with esbuild
- **Production**: `npm run start` serves the compiled application
- **Port configuration**: Backend runs on port 5000, exposed as port 80
- **Database**: PostgreSQL 16 module configured in Replit environment
- **Auto-scaling**: Configured for autoscale deployment target

### Environment Setup
- **Node.js 20** runtime
- **PostgreSQL 16** database module
- **Environment variables**: DATABASE_URL required for production
- **Static file serving**: Built frontend served from dist/public

## Changelog
- June 26, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.