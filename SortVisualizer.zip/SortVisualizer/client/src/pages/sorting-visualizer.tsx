import { useState, useEffect, useCallback, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { LoadingOverlay } from '@/components/ui/loading-overlay';
import { ClimbingCharacter } from '@/components/ui/climbing-character';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Play, RotateCcw, BarChart3, Code } from 'lucide-react';
import { sortingAlgorithms, algorithmInfo, type SortStep } from '@/lib/sorting-algorithms';

type Algorithm = keyof typeof sortingAlgorithms;
type Speed = 'slow' | 'medium' | 'fast';

const speedMap: Record<Speed, number> = {
  slow: 1000,
  medium: 500,
  fast: 100
};

export default function SortingVisualizer() {
  const [array, setArray] = useState<number[]>([]);
  const [algorithm, setAlgorithm] = useState<Algorithm>('bubble');
  const [arraySize, setArraySize] = useState(50);
  const [speed, setSpeed] = useState<Speed>('medium');
  const [isSorting, setIsSorting] = useState(false);
  const [currentStep, setCurrentStep] = useState<SortStep | null>(null);
  const [stats, setStats] = useState({ comparisons: 0, swaps: 0, time: 0 });
  const [status, setStatus] = useState<'ready' | 'sorting' | 'complete'>('ready');
  const [showQuiz, setShowQuiz] = useState(false);
  const [quizAnswer, setQuizAnswer] = useState<string>('');
  const [quizResult, setQuizResult] = useState<'correct' | 'incorrect' | null>(null);
  
  const startTimeRef = useRef<number>(0);
  const animationRef = useRef<NodeJS.Timeout | null>(null);

  const generateArray = useCallback(() => {
    const newArray = Array.from({ length: arraySize }, () => Math.floor(Math.random() * 80) + 10);
    setArray(newArray);
    setCurrentStep(null);
    setStats({ comparisons: 0, swaps: 0, time: 0 });
    setStatus('ready');
    setShowQuiz(false);
    setQuizAnswer('');
    setQuizResult(null);
  }, [arraySize]);

  useEffect(() => {
    generateArray();
  }, [generateArray]);

  const startSorting = async () => {
    if (isSorting) return;
    
    setIsSorting(true);
    setStatus('sorting');
    setStats({ comparisons: 0, swaps: 0, time: 0 });
    startTimeRef.current = Date.now();
    
    const generator = sortingAlgorithms[algorithm](array);
    let comparisons = 0;
    let swaps = 0;
    
    const animate = () => {
      const { value, done } = generator.next();
      
      if (done) {
        setStatus('complete');
        setIsSorting(false);
        setStats(prev => ({ ...prev, time: Date.now() - startTimeRef.current }));
        // Show quiz popup after sorting completes
        setTimeout(() => setShowQuiz(true), 1500);
        return;
      }
      
      if (value.comparing) comparisons++;
      if (value.swapping) swaps++;
      
      setCurrentStep(value);
      setStats({ comparisons, swaps, time: Date.now() - startTimeRef.current });
      
      animationRef.current = setTimeout(animate, speedMap[speed]);
    };
    
    animate();
  };

  const stopSorting = () => {
    if (animationRef.current) {
      clearTimeout(animationRef.current);
      animationRef.current = null;
    }
    setIsSorting(false);
    setStatus('ready');
  };

  const handleQuizAnswer = (selectedAnswer: string) => {
    setQuizAnswer(selectedAnswer);
    const correctAnswer = algorithmInfo[algorithm].complexities.average;
    const isCorrect = selectedAnswer === correctAnswer;
    setQuizResult(isCorrect ? 'correct' : 'incorrect');
  };

  const closeQuiz = () => {
    setShowQuiz(false);
    setQuizAnswer('');
    setQuizResult(null);
  };

  const quizOptions = ['O(n)', 'O(n log n)', 'O(n²)', 'O(2^n)'];

  useEffect(() => {
    return () => {
      if (animationRef.current) {
        clearTimeout(animationRef.current);
        animationRef.current = null;
      }
    };
  }, []);

  const getBarClassName = (index: number) => {
    if (!currentStep) return 'array-bar';
    
    let className = 'array-bar';
    
    if (currentStep.sorted?.includes(index)) {
      className += ' sorted';
    } else if (currentStep.swapping?.includes(index)) {
      className += ' swapping';
    } else if (currentStep.comparing?.includes(index)) {
      className += ' comparing';
    }
    
    return className;
  };

  const currentAlgorithmInfo = algorithmInfo[algorithm];
  const displayArray = currentStep ? currentStep.array : array;

  return (
    <div className="min-h-screen bg-background-alt">
      {/* Header */}
      <header className="bg-surface shadow-sm border-b border-gray-200">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <BarChart3 className="text-white text-lg" />
              </div>
              <div>
                <h1 className="text-2xl font-medium text-secondary">Sorting Algorithm Visualizer</h1>
                <p className="text-sm text-gray-600">Interactive visualization of sorting algorithms</p>
              </div>
            </div>
            <div className="hidden md:flex items-center space-x-4 text-sm text-gray-600">
              <span><Code className="inline mr-1 h-4 w-4" />HTML, CSS, JavaScript</span>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Control Panel */}
        <Card className="mb-8 animate-slide-up">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {/* Algorithm Selection */}
              <div className="space-y-2">
                <label className="block text-sm font-medium text-secondary">Algorithm</label>
                <Select value={algorithm} onValueChange={(value) => setAlgorithm(value as Algorithm)} disabled={isSorting}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="bubble">Bubble Sort</SelectItem>
                    <SelectItem value="selection">Selection Sort</SelectItem>
                    <SelectItem value="insertion">Insertion Sort</SelectItem>
                    <SelectItem value="quick">Quick Sort</SelectItem>
                    <SelectItem value="merge">Merge Sort</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Array Size */}
              <div className="space-y-2">
                <label className="block text-sm font-medium text-secondary">Array Size</label>
                <div className="flex items-center space-x-2">
                  <Slider
                    value={[arraySize]}
                    onValueChange={(value) => setArraySize(value[0])}
                    min={2}
                    max={50}
                    step={1}
                    disabled={isSorting}
                    className="flex-1"
                  />
                  <span className="text-sm font-medium text-secondary w-8 text-center">{arraySize}</span>
                </div>
              </div>

              {/* Speed Control */}
              <div className="space-y-2">
                <label className="block text-sm font-medium text-secondary">Speed</label>
                <Select value={speed} onValueChange={(value) => setSpeed(value as Speed)} disabled={isSorting}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="slow">Slow (1000ms)</SelectItem>
                    <SelectItem value="medium">Medium (500ms)</SelectItem>
                    <SelectItem value="fast">Fast (100ms)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2">
                <label className="block text-sm font-medium text-secondary">Actions</label>
                <div className="flex space-x-2">
                  <Button 
                    variant="secondary" 
                    onClick={generateArray} 
                    disabled={isSorting}
                    className="flex-1"
                  >
                    <RotateCcw className="mr-1 h-4 w-4" />
                    Generate
                  </Button>
                  <Button 
                    onClick={isSorting ? stopSorting : startSorting} 
                    className="flex-1"
                  >
                    <Play className="mr-1 h-4 w-4" />
                    {isSorting ? 'Stop' : 'Sort'}
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Algorithm Information */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Current Algorithm Info */}
          <div className="lg:col-span-2">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-medium text-secondary">
                    Current Algorithm: <span className="text-primary">{currentAlgorithmInfo.name}</span>
                  </h3>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-gray-600">Status:</span>
                    <Badge variant={status === 'complete' ? 'default' : status === 'sorting' ? 'secondary' : 'outline'}>
                      {status === 'ready' ? 'Ready' : status === 'sorting' ? 'Sorting...' : 'Complete'}
                    </Badge>
                  </div>
                </div>
                <p className="text-gray-600 mb-4">{currentAlgorithmInfo.description}</p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline" className="complexity-badge bg-blue-100 text-blue-800">
                    Best: {currentAlgorithmInfo.complexities.best}
                  </Badge>
                  <Badge variant="outline" className="complexity-badge bg-orange-100 text-orange-800">
                    Average: {currentAlgorithmInfo.complexities.average}
                  </Badge>
                  <Badge variant="outline" className="complexity-badge bg-red-100 text-red-800">
                    Worst: {currentAlgorithmInfo.complexities.worst}
                  </Badge>
                  <Badge variant="outline" className="complexity-badge bg-green-100 text-green-800">
                    Space: {currentAlgorithmInfo.complexities.space}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Legend */}
          <Card>
            <CardContent className="p-6">
              <h3 className="text-lg font-medium text-secondary mb-4">Legend</h3>
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <div className="w-4 h-4 bg-[var(--default-bar)] rounded"></div>
                  <span className="text-sm text-gray-600">Unsorted</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-4 h-4 bg-[var(--comparing)] rounded"></div>
                  <span className="text-sm text-gray-600">Comparing</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-4 h-4 bg-[var(--swapping)] rounded"></div>
                  <span className="text-sm text-gray-600">Swapping</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-4 h-4 bg-[var(--sorted)] rounded"></div>
                  <span className="text-sm text-gray-600">Sorted</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Visualization Area */}
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-medium text-secondary">Array Visualization</h3>
              <div className="flex items-center space-x-4 text-sm text-gray-600">
                <span>Comparisons: <span className="font-medium text-primary">{stats.comparisons}</span></span>
                <span>Swaps: <span className="font-medium text-[var(--swapping)]">{stats.swaps}</span></span>
                <span>Time: <span className="font-medium text-[var(--sorted)]">{stats.time}ms</span></span>
              </div>
            </div>
            
            {/* Array Container */}
            <div className="relative">
              <div className={`flex items-end justify-center space-x-1 min-h-[500px] p-4 rounded-lg border-2 border-dashed border-gray-200 ${
                status === 'complete' ? 'sorted-celebration' : 'bg-gray-50'
              }`}>
                {displayArray.map((value, index) => {
                  const barWidth = Math.max(2, Math.floor((800 - 40) / displayArray.length) - 2);
                  return (
                    <div
                      key={`${index}-${value}`}
                      className={getBarClassName(index)}
                      style={{
                        width: `${barWidth}px`,
                        height: `${value}px`,
                        display: 'inline-block',
                        marginRight: '2px',
                        position: 'relative'
                      }}
                    >
                      {barWidth > 8 && (
                        <div 
                          className="absolute text-xs font-bold text-center text-black"
                          style={{ 
                            fontSize: barWidth > 20 ? '10px' : '8px',
                            lineHeight: '1.2',
                            bottom: '2px',
                            left: '50%',
                            transform: 'translateX(-50%)',
                            textShadow: '1px 1px 1px rgba(255,255,255,0.8)',
                            whiteSpace: 'nowrap'
                          }}
                        >
                          {value}
                        </div>
                      )}
                      
                      {/* Climbing Character Animation */}
                      {currentStep?.sorted?.includes(index) && (
                        <ClimbingCharacter
                          isVisible={true}
                          barHeight={value}
                          barWidth={barWidth}
                          delay={index * 50}
                        />
                      )}
                    </div>
                  );
                })}
                
                {/* Celebration Elements */}
                {status === 'complete' && (
                  <div className="celebration-message">
                    🎉 Sorting Complete! 🎉
                  </div>
                )}
              </div>
              

            </div>
          </CardContent>
        </Card>

        {/* Performance Stats */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-primary mb-2">{stats.comparisons}</div>
              <div className="text-sm text-gray-600">Total Comparisons</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-[var(--swapping)] mb-2">{stats.swaps}</div>
              <div className="text-sm text-gray-600">Total Swaps</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-[var(--sorted)] mb-2">{stats.time}ms</div>
              <div className="text-sm text-gray-600">Total Time</div>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-surface border-t border-gray-200 mt-16">
        <div className="container mx-auto px-4 py-8">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="text-sm text-gray-600 mb-4 md:mb-0">
              <p>Built with HTML, CSS, and JavaScript</p>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">Educational purposes only</span>
            </div>
          </div>
        </div>
      </footer>

      {/* Quiz Dialog */}
      <Dialog open={showQuiz} onOpenChange={closeQuiz}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center">Algorithm Quiz 🧠</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-center text-gray-700">
              What was the time complexity of <strong>{algorithmInfo[algorithm].name}</strong> that you just saw?
            </p>
            
            <div className="grid grid-cols-2 gap-3">
              {quizOptions.map((option) => (
                <Button
                  key={option}
                  variant={quizAnswer === option ? 'default' : 'outline'}
                  onClick={() => handleQuizAnswer(option)}
                  className={`
                    ${quizAnswer === option && quizResult === 'correct' ? 'bg-green-500 hover:bg-green-600' : ''}
                    ${quizAnswer === option && quizResult === 'incorrect' ? 'bg-red-500 hover:bg-red-600' : ''}
                  `}
                  disabled={quizResult !== null}
                >
                  {option}
                </Button>
              ))}
            </div>

            {quizResult && (
              <div className={`text-center p-3 rounded-lg ${
                quizResult === 'correct' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
              }`}>
                {quizResult === 'correct' ? (
                  <div>
                    <p className="font-semibold">🎉 Correct!</p>
                    <p className="text-sm mt-1">
                      {algorithmInfo[algorithm].name} has an average time complexity of {algorithmInfo[algorithm].complexities.average}
                    </p>
                  </div>
                ) : (
                  <div>
                    <p className="font-semibold">❌ Not quite right</p>
                    <p className="text-sm mt-1">
                      The correct answer is <strong>{algorithmInfo[algorithm].complexities.average}</strong>
                    </p>
                  </div>
                )}
              </div>
            )}

            <div className="flex justify-center pt-2">
              <Button onClick={closeQuiz} variant="outline">
                {quizResult ? 'Close' : 'Skip Quiz'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
