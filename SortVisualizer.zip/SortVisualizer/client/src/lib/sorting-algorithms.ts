export interface SortStep {
  array: number[];
  comparing?: number[];
  swapping?: number[];
  sorted?: number[];
  pivot?: number;
}

export interface AlgorithmInfo {
  name: string;
  description: string;
  complexities: {
    best: string;
    average: string;
    worst: string;
    space: string;
  };
}

export const algorithmInfo: Record<string, AlgorithmInfo> = {
  bubble: {
    name: 'Bubble Sort',
    description: 'Bubble sort repeatedly steps through the list, compares adjacent elements and swaps them if they are in the wrong order. The pass through the list is repeated until the list is sorted.',
    complexities: {
      best: 'O(n)',
      average: 'O(n²)',
      worst: 'O(n²)',
      space: 'O(1)'
    }
  },
  selection: {
    name: 'Selection Sort',
    description: 'Selection sort divides the input list into two parts: sorted and unsorted. It repeatedly selects the smallest element from the unsorted portion and moves it to the sorted portion.',
    complexities: {
      best: 'O(n²)',
      average: 'O(n²)',
      worst: 'O(n²)',
      space: 'O(1)'
    }
  },
  insertion: {
    name: 'Insertion Sort',
    description: 'Insertion sort builds the final sorted array one item at a time. It is much less efficient on large lists than more advanced algorithms such as quicksort, heapsort, or merge sort.',
    complexities: {
      best: 'O(n)',
      average: 'O(n²)',
      worst: 'O(n²)',
      space: 'O(1)'
    }
  },
  quick: {
    name: 'Quick Sort',
    description: 'Quick sort picks an element as pivot and partitions the array around the pivot. It recursively sorts the sub-arrays on either side of the pivot.',
    complexities: {
      best: 'O(n log n)',
      average: 'O(n log n)',
      worst: 'O(n²)',
      space: 'O(log n)'
    }
  },
  merge: {
    name: 'Merge Sort',
    description: 'Merge sort divides the array into halves, recursively sorts them, and then merges the sorted halves. It is a stable sort with consistent O(n log n) performance.',
    complexities: {
      best: 'O(n log n)',
      average: 'O(n log n)',
      worst: 'O(n log n)',
      space: 'O(n)'
    }
  }
};

export function* bubbleSort(array: number[]): Generator<SortStep> {
  const arr = [...array];
  const n = arr.length;
  const sorted: number[] = [];

  for (let i = 0; i < n - 1; i++) {
    let swapped = false;
    for (let j = 0; j < n - i - 1; j++) {
      yield { array: [...arr], comparing: [j, j + 1], sorted: [...sorted] };
      
      if (arr[j] > arr[j + 1]) {
        yield { array: [...arr], swapping: [j, j + 1], sorted: [...sorted] };
        [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];
        swapped = true;
      }
    }
    sorted.unshift(n - i - 1);
    if (!swapped) break;
  }
  
  yield { array: [...arr], sorted: Array.from({ length: n }, (_, i) => i) };
}

export function* selectionSort(array: number[]): Generator<SortStep> {
  const arr = [...array];
  const n = arr.length;
  const sorted: number[] = [];

  for (let i = 0; i < n - 1; i++) {
    let minIdx = i;
    
    for (let j = i + 1; j < n; j++) {
      yield { array: [...arr], comparing: [minIdx, j], sorted: [...sorted] };
      if (arr[j] < arr[minIdx]) {
        minIdx = j;
      }
    }
    
    if (minIdx !== i) {
      yield { array: [...arr], swapping: [i, minIdx], sorted: [...sorted] };
      [arr[i], arr[minIdx]] = [arr[minIdx], arr[i]];
    }
    
    sorted.push(i);
  }
  
  yield { array: [...arr], sorted: Array.from({ length: n }, (_, i) => i) };
}

export function* insertionSort(array: number[]): Generator<SortStep> {
  const arr = [...array];
  const n = arr.length;
  const sorted = [0];

  for (let i = 1; i < n; i++) {
    const key = arr[i];
    let j = i - 1;
    
    yield { array: [...arr], comparing: [i], sorted: [...sorted] };
    
    while (j >= 0 && arr[j] > key) {
      yield { array: [...arr], comparing: [j, j + 1], sorted: [...sorted] };
      yield { array: [...arr], swapping: [j, j + 1], sorted: [...sorted] };
      arr[j + 1] = arr[j];
      j--;
    }
    
    arr[j + 1] = key;
    sorted.push(i);
  }
  
  yield { array: [...arr], sorted: Array.from({ length: n }, (_, i) => i) };
}

export function* quickSort(array: number[]): Generator<SortStep> {
  const arr = [...array];
  const sorted: number[] = [];
  
  function* quickSortHelper(low: number, high: number): Generator<SortStep> {
    if (low < high) {
      const pivotIndex = yield* partition(low, high);
      yield* quickSortHelper(low, pivotIndex - 1);
      yield* quickSortHelper(pivotIndex + 1, high);
    } else if (low === high) {
      sorted.push(low);
    }
  }
  
  function* partition(low: number, high: number): Generator<SortStep, number> {
    const pivot = arr[high];
    let i = low - 1;
    
    yield { array: [...arr], pivot: high, sorted: [...sorted] };
    
    for (let j = low; j < high; j++) {
      yield { array: [...arr], comparing: [j, high], pivot: high, sorted: [...sorted] };
      
      if (arr[j] < pivot) {
        i++;
        if (i !== j) {
          yield { array: [...arr], swapping: [i, j], pivot: high, sorted: [...sorted] };
          [arr[i], arr[j]] = [arr[j], arr[i]];
        }
      }
    }
    
    if (i + 1 !== high) {
      yield { array: [...arr], swapping: [i + 1, high], sorted: [...sorted] };
      [arr[i + 1], arr[high]] = [arr[high], arr[i + 1]];
    }
    
    sorted.push(i + 1);
    return i + 1;
  }
  
  yield* quickSortHelper(0, arr.length - 1);
  yield { array: [...arr], sorted: Array.from({ length: arr.length }, (_, i) => i) };
}

export function* mergeSort(array: number[]): Generator<SortStep> {
  const arr = [...array];
  const sorted: number[] = [];
  
  function* mergeSortHelper(left: number, right: number): Generator<SortStep> {
    if (left >= right) return;
    
    const mid = Math.floor((left + right) / 2);
    
    yield* mergeSortHelper(left, mid);
    yield* mergeSortHelper(mid + 1, right);
    yield* merge(left, mid, right);
  }
  
  function* merge(left: number, mid: number, right: number): Generator<SortStep> {
    const leftArr = arr.slice(left, mid + 1);
    const rightArr = arr.slice(mid + 1, right + 1);
    
    let i = 0, j = 0, k = left;
    
    while (i < leftArr.length && j < rightArr.length) {
      yield { array: [...arr], comparing: [left + i, mid + 1 + j], sorted: [...sorted] };
      
      if (leftArr[i] <= rightArr[j]) {
        arr[k] = leftArr[i];
        i++;
      } else {
        arr[k] = rightArr[j];
        j++;
      }
      k++;
    }
    
    while (i < leftArr.length) {
      arr[k] = leftArr[i];
      i++;
      k++;
    }
    
    while (j < rightArr.length) {
      arr[k] = rightArr[j];
      j++;
      k++;
    }
    
    for (let idx = left; idx <= right; idx++) {
      sorted.push(idx);
    }
  }
  
  yield* mergeSortHelper(0, arr.length - 1);
  yield { array: [...arr], sorted: Array.from({ length: arr.length }, (_, i) => i) };
}

export const sortingAlgorithms = {
  bubble: bubbleSort,
  selection: selectionSort,
  insertion: insertionSort,
  quick: quickSort,
  merge: mergeSort
};
