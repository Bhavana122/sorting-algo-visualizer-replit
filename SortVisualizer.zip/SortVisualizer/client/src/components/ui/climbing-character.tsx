import { useState, useEffect } from 'react';

interface ClimbingCharacterProps {
  isVisible: boolean;
  barHeight: number;
  barWidth: number;
  delay?: number;
}

export function ClimbingCharacter({ 
  isVisible, 
  barHeight, 
  barWidth,
  delay = 0
}: ClimbingCharacterProps) {
  const [isClimbing, setIsClimbing] = useState(false);

  useEffect(() => {
    if (isVisible) {
      const startTimer = setTimeout(() => {
        setIsClimbing(true);
        const endTimer = setTimeout(() => setIsClimbing(false), 2500);
        return () => clearTimeout(endTimer);
      }, delay);
      return () => clearTimeout(startTimer);
    }
  }, [isVisible, delay]);

  if (!isVisible || !isClimbing) return null;

  // Random character selection for fun
  const characters = ['🍄', '⭐', '🐢', '👑', '🔥', '💎', '🌟', '🦄'];
  const character = characters[Math.floor(Math.random() * characters.length)];

  return (
    <div
      className="absolute pointer-events-none z-20"
      style={{
        bottom: '0px',
        left: '50%',
        transform: 'translateX(-50%)',
        fontSize: Math.min(barWidth * 0.7, 14) + 'px',
        animation: `climbUp 2.5s ease-out forwards`,
        animationDelay: '0.2s'
      }}
    >
      <div className="character-bounce">
        {character}
      </div>
    </div>
  );
}